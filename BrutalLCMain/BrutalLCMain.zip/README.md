---
[![Discord](https://i.imgur.com/4tL11ab.png)](https://discord.gg/Z9rUwTtUpx)

## MoreBrutalLCMain
### It contains all main mods to work for [MoreBrutalLethalCompanyPlus](https://thunderstore.io/c/lethal-company/p/seechela/MoreBrutalLethalCompanyPlus/)!

## Changelog
New updates changelog will be uploaded to [MoreBrutalLethalCompanyPlus](https://thunderstore.io/c/lethal-company/p/seechela/MoreBrutalLethalCompanyPlus/)!

If you want to suggest, play with friends on this modpack then go to my [discord server](https://discord.gg/T6DTSuC8dK).

</details>

---